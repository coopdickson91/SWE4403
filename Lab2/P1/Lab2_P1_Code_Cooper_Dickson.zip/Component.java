
public interface Component{
    /* TODO Implement an appropriate interface method */
    public Component clone();

}
