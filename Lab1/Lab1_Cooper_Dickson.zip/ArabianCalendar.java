
import java.util.Date;

public class ArabianCalendar implements Calendar{
    
    public void addEvent(Event event, Date date){
        System.out.println("Adding an event on the Arabian Calendar");
    }
}