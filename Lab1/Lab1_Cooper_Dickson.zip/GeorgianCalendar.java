
import java.util.Date;

public class GeorgianCalendar implements Calendar{
    
    public void addEvent(Event event, Date date){
        System.out.println("Adding an event on the Georgian Calendar");
    }
}