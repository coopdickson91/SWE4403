class MyThread extends Thread {
    
  public void run() {
    System.out.println("Thread running: " + this.getName());
  }
}